// JavaScript Document

function extendJQ(){
	$.fn.scrollView = function () {
		return this.each(function () {
			$('html, body').animate({
				scrollTop: $(this).offset().top
			}, 400);
		});
	}
	
	$.fn.glow = function(){
		var pbg = this.bgcolor();
		var rpbg = this.css("backgroundColor");
		return this.animate({ backgroundColor: "#FC0" }, 400).animate({ backgroundColor: pbg }, 400, function(){
			$(this).css("backgroundColor", rpbg)});
	};
	
	$.fn.bgcolor = function(){
		var bgc = this.css("backgroundColor");
		if (bgc == "transparent"){
			return this.parent().bgcolor();
		}else {
			return bgc;	
		}
	}
}

$(document).ready(function(){

	extendJQ();

	//Hide (Collapse) the toggle containers on load
	$(".toggle-content").hide(); 

	//Load the current problem table
	$("#problem-visualization").load("res/problem-table.html", function(){
	
		$(".problem-vis-table").delegate('td','mouseover mouseleave', function(e) {
			if (e.type == 'mouseover') {
				$(this).parent().addClass("hilite");
				$(".problem-vis-table ."+$(this).attr("class")).addClass("hilite");
				$(this).addClass("hovered");
			}
			else {
				$(this).parent().removeClass("hilite");
				$(".problem-vis-table td").removeClass("hilite");
				$(this).removeClass("hovered");
			}
		});
			
	});

	//Load the current scenario
	$("#scenario-log").load("res/scenario.html", function(){
		$(".log").prepend("<img src=\"res/log.png\" />");
		$(".message").prepend("<img src=\"res/message.png\"/>");	
		$(".rec-message").prepend("&nbsp;<img src=\"res/open-message.png\"/>&nbsp;");	
		
		//when clicking on the message sent - scroll to view it and then glow to indicate it
		$("#scenario-log a").click( function(){
			var dest = $( $(this).attr("href"));
			if (dest.length == 0){
				$.msg({content: "<h1>Algorithm ends before message received!</h1>", timeOut: 1500});
			}else {
				dest.scrollView().parent().glow();
			}
			
		});
		
		$("#scenario-log a.rec-message").unbind('click').click( function(){
			var dest = $( $(this).attr("href"));
			dest.parent().parent().scrollView()
			dest.parent().glow();
		});
		
	});
	
	//Load the executed environment
	$("#environment").load("res/environment.html", function(){
		$("#env-problem").prepend("<img src=\"res/problem.png\"/>");	
		$("#env-algorithm").prepend("<img src=\"res/algorithm.png\"/>");	
	});
	
	//Load the execution result
	$("#result").load("res/result.html");
		
	//Switch the "Open" and "Close" state per click then slide up/down (depending on open/close state)
	$("h2.trigger").click(function(){
		$(this).toggleClass("active").next().slideToggle("fast");
		if ($(this).find("img").attr("src") == "res/toggle.png"){
			$(this).find("img").attr("src", "res/toggle-expand.png");
		}else{
			$(this).find("img").attr("src", "res/toggle.png");
		}
		return false; //Prevent the browser jump to the link anchor
	});

});